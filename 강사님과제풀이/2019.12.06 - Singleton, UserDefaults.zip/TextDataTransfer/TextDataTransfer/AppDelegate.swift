//
//  AppDelegate.swift
//  TextDataTransfer
//
//  Created by Giftbot on 2019/11/30
//  Copyright © 2019 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

}
