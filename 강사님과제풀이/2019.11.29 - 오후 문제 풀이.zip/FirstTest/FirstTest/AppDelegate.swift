//
//  AppDelegate.swift
//  FirstTest
//
//  Created by Giftbot on 2019/11/30.
//  Copyright © 2019 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

}
