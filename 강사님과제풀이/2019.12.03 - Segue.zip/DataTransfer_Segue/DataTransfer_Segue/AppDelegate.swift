//
//  AppDelegate.swift
//  DataTransfer_Segue
//
//  Created by Giftbot on 2019/12/01.
//  Copyright © 2019 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

}
