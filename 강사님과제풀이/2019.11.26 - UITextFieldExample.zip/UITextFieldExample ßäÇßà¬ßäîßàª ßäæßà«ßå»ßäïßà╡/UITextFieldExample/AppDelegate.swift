//
//  AppDelegate.swift
//  UITextFieldExample
//
//  Created by 이봉원 on 20/11/2019.
//  Copyright © 2019 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

}
