//
//  MainTabBarController.swift
//  TestDomino
//
//  Created by 황정덕 on 2020/01/29.
//  Copyright © 2020 Gitbot. All rights reserved.
//

import UIKit

class MainTabBarController: UITabBarController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
    let sectnionVC = UINavigationController(rootViewController: SectionViewController())
    let wishListVC = UINavigationController(rootViewController: WishListViewController())
    sectnionVC.tabBarItem = UITabBarItem(title: "Section", image: UIImage(named: "domino's"), tag: 0)
    wishListVC.tabBarItem = UITabBarItem(title: "WishList", image: nil, tag: 1)
    viewControllers = [sectnionVC, wishListVC]
  }
  
  
  
}
