/*:
 # JSONSerialization
 
 - [Creating JSON](Creating%20JSON)
 - [Parsing JSON](Parsing%20JSON)
 - [Practice](Practice)
 - [Answer](Answer)
 
 by Giftbot
*/
//: [Next](@next)
