//
//  AppDelegate.swift
//  FoldingMenusExample
//
//  Created by giftbot on 2020/01/07..
//  Copyright © 2020년 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?

}

