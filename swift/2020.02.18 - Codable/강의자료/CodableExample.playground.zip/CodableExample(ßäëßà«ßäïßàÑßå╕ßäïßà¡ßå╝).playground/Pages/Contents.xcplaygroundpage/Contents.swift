/*:
 # Codable
 
 - [JSON](JSON)
 - [PropertyList](PropertyList)
 - [versus Serialization](versus%20Serialization)
 - [Change Key Names](Change%20Key%20Names)
 - [Nested Codable](Nested%20Codable)
 - [Nested Keys](Nested%20Keys)
 - [Practice](Practice)
 - [Answer](Answer)

 by Giftbot
 
*/
//: [Next](@next)
