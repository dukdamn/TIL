/*:
 # Higher Order Function
 * **Higher-Order Function**
 * **Functions**
   - forEach
   - map
   - filter
   - reduce
   - compactMap
   - flatMap
 * **Practice**
 
 by Giftbot
 */

//: [Next](@next)
