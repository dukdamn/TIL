//
//  ViewController.swift
//  UistackViewDec16th
//
//  Created by macbook on 2019/12/16.
//  Copyright © 2019 Lance. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

