/*:
 # Closure
 
 - Closure
 - CaptureList
 - CaptureExample
 - NoEscaping
 - Escaping
 - Compatibility
 - MemoryLeak
 - AutoClosure
 
 by Giftbot
*/
//: [Next](@next)
