//
//  WishListController.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class WishListController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Do any additional setup after appearing the view.
        tableView.reloadData()
        
    }
    
    private let userData = UserData.main
    private let tableView = UITableView()
    private func setupUI() {
        self.view.backgroundColor = .white
        self.navigationItem.title = "WishList"
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "목록 지우기", style: .plain, target: self, action: #selector(deleteList(_:)))
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "주문", style: .plain, target: self, action: #selector(order(_:)))
        
        tableView.dataSource = self
        self.view.addSubview(tableView)
        
        setupConstraint()
    }
    
    private func setupConstraint() {
        let guide = self.view.safeAreaLayoutGuide
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: guide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
        ])
    }
    
    // MARK:- Action
    
    @objc private func deleteList(_ sender: UIBarButtonItem) {
        userData.removeAll()
        tableView.reloadData()
    }

    @objc private func order(_ sender: UIBarButtonItem) {
        print("주문")
    }
}

// MARK:- UITableViewDataSource

extension WishListController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userData.numberOfData
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell: UITableViewCell
        if let menuCell = tableView.dequeueReusableCell(withIdentifier: "WishListCell") {
            cell = menuCell
        } else {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "WishListCell")
        }
        
        let data = userData.fetch(at: indexPath.row)
        
        cell.imageView?.image = UIImage(named: data.thumbnail)
        cell.textLabel?.text = data.name
        cell.detailTextLabel?.text = "\(data.ordered) 개"
        return cell
    }
}
