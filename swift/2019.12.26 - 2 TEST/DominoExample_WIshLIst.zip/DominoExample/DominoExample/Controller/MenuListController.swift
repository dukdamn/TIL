//
//  MenuListController.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class MenuListController: UIViewController {

//    var menuTitle = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }
    
    var menuInfo: DominoMenu?
    
    let tableView = UITableView()
    private func setupUI() {
        self.view.backgroundColor = .white
        
        self.navigationItem.title = menuInfo?.category ?? ""
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.rowHeight = 120
//        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "MenuCell")
        self.view.addSubview(tableView)

        self.setupConstraint()
    }
    
    var constraint: NSLayoutConstraint!
    private func setupConstraint() {
        let guide = self.view.safeAreaLayoutGuide
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: guide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
        ])
    }
}

// MARK:- UITableViewDataSource

extension MenuListController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuInfo?.menus.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "MenuCell", for: indexPath)
        
        let cell: UITableViewCell
        if let menuCell = tableView.dequeueReusableCell(withIdentifier: "MenuCell") {
            cell = menuCell
        } else {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: "MenuCell")
        }
        
        let menu = menuInfo?.menus[indexPath.row]
        cell.imageView?.image = UIImage(named: menu?.thumbnail ?? "")
        cell.textLabel?.text = menu?.name ?? ""
        cell.detailTextLabel?.text = "\(menu?.price ?? 0)원"
        return cell
    }
}

// MARK:- UITableViewDelegate

extension MenuListController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC = DetailMenuController()
        
        detailVC.menu = menuInfo?.menus[indexPath.row]
       
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}
