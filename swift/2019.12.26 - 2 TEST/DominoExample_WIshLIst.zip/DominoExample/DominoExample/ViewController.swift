//
//  ViewController.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class OrderViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .green
    }


}

