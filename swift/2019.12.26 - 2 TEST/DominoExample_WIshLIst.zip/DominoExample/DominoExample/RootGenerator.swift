//
//  WindowGenerator.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

class RootGenerator {
    static let shared = RootGenerator()
    
    private init() { }
    
    func make() -> UIViewController {
        let orderVC = OrderViewController()
        let orderNaviVC = UINavigationController(rootViewController: orderVC)
        orderNaviVC.tabBarItem = UITabBarItem(title: "Domino's", image: nil, tag: 0)
        
        let wishVC = WishListController()
        let wishNaviVC = UINavigationController(rootViewController: wishVC)
        wishNaviVC.tabBarItem = UITabBarItem(title: "WishList", image: nil, tag: 1)
        
        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [orderNaviVC, wishNaviVC]
        
        return tabBarController
    }
}
