//
//  UserData.swift
//  DominoExample
//
//  Created by cskim on 2019/12/27.
//  Copyright © 2019 cskim. All rights reserved.
//

import Foundation

class UserData {
    
    // MARK:- Singleton
    
    static let main = UserData()
    private init() { }
    
    // MARK:- Properties
    
    var numberOfData = 0
    private var wishList = [Menu]() {
        didSet {
            numberOfData = wishList.count
        }
    }
    
    // MARK:- Update
    
    func update(menu: Menu) {
        if let index = wishList.firstIndex(of: menu) {
            wishList[index] = menu
        } else {
            wishList.append(menu)
        }
    }
    
    func remove(menu: Menu) {
        if let index = wishList.firstIndex(of: menu) {
            wishList.remove(at: index)
        }
    }
    
    func removeAll() {
        for menu in wishList {
            menu.ordered = 0
        }
        wishList.removeAll()
    }
    
    // MARK:- Notify
    
    func fetch(at index: Int) -> Menu {
        return wishList[index]
    }
}
