//
//  Menu.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import UIKit

var value = 0

struct DominoMenu {
    var category: String
    var menus: [Menu]
}

class Menu: Equatable {
    var name: String
    var price: Int
    var thumbnail: String
    var ordered: Int
    
    init(name: String, price: Int, thumbnail: String, ordered: Int = 0) {
        self.name = name
        self.price = price
        self.thumbnail = thumbnail
        self.ordered = ordered
    }
    
    static func == (lhs: Menu, rhs: Menu) -> Bool {
        return (lhs.name == rhs.name) &&
            (lhs.price == rhs.price) &&
            (lhs.thumbnail == rhs.thumbnail)
    }
}
