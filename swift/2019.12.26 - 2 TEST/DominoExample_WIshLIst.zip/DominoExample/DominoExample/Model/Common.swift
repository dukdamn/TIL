//
//  Common.swift
//  DominoExample
//
//  Created by cskim on 2019/12/26.
//  Copyright © 2019 cskim. All rights reserved.
//

import Foundation
import UIKit

struct DominoImage {
    static let logo = "dominoLogo"
    static let hotPizza = "hotPizza"
    static let meatPizza = "meatPizza"
    static let shrimpPizza = "shirimpPizza"
    static let whitePizza = "whitePizza"
    static let wideBanner = "wideBanner"
}
