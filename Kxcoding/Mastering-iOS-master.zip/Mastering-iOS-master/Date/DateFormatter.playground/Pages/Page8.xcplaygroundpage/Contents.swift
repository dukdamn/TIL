//: [Previous](@previous)

import Foundation

let startDate = Date()
let endDate = startDate.addingTimeInterval(3600 * 24 * 30)


//: [Next](@next)
